#importowanie 
import time, os

#dzialanie 

print("odpalanie auto destrukcji")
time.sleep(1)
print("za")
time.sleep(0.6)
print("4")
time.sleep(0.9)
print("3")
time.sleep(0.9)
print("2")
time.sleep(1.2)
print("1")

time.sleep(1.3)

print("auto destrukcja")

time.sleep(0.8)

print(".")

time.sleep(0.6)

print("..")

time.sleep(0.9)

print("...")

time.sleep(1.3)

print("jk")

time.sleep(2.2)

#papuga 
os.system("curl parrot.live")
